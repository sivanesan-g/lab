//package employee;
public class AssociateProfessor extends Employee
{
private float bPay;
private String des;
public AssociateProfessor(String name, String id, String address, String mailId, String
mobileNo, float bPay, String des)
{
super(name, id, address, mailId, mobileNo);
this.bPay= bPay;
this.des= des;
}
public void paySlip()
{
float da=bPay*97/100;
float hra=bPay*10/100;
double grossSalary=bPay + da + hra;
float pf=bPay*12/100;
double scf=bPay*0.1/100;
double netSalary=grossSalary - pf - scf;
System.out.println("------------ Employees Pay Slips ------------");
super.display();
System.out.println("Designation: "+des);
System.out.println("Basic_Pay: "+bPay);
System.out.println("Gross Salary : "+ grossSalary + "\t" + "Net Salary : " + netSalary);
System.out.println("------------ End of the Statements -----------");
}
}
//