public class Employee
{
private String name;
private String id;
private String address;
private String mailId;
private String mobileNo;
public Employee(String name, String id, String address, String mailId, String mobileNo)
{
this.name= name;
this.id= id;
this.address= address;
this.mailId= mailId;
this.mobileNo= mobileNo;
}
public void display()
{
System.out.println("Emp_Name : "+ name + "\t" + "Emp_id : "+ id);
System.out.println("Address : " + address);
System.out.println("Mail_id : "+ mailId + "\t" + "Mobile_no : " + mobileNo);
}
public void paySlip()
{
}
}
//