import os

color=["\033[1;31m","\033[1;32m","\033[1;33m","\033[1;34m","\033[1;35m","\033[1;36m"]
file_name =["java Ebbill ","java Converter","java Emp","java StackAdt","java Area","java UserException","java FileInfo","java Multithread","java MyGeneric","java ScientificCalculator"]
lab_topic=["GENERATING ELECTRICITY BILL","CURRENCY CONVERTER, DISTANCE CONVERTER AND TIME CONVERTERUSING PACKAGES","GENERATING EMPLOYEE PAYROLL DETAILS","DESIGN A JAVA INTERFACE FOR ADT STACK","FINDING THE AREA OF DIFFERENT SHAPES","CREATING OWN EXCEPTIONS","GETTING FILE INFORMATION","MULTI THREADED APPLICATION","GENERIC PROGRAMMING","EVENT - DRIVEN PROGRAMMING"]
c=0
fn=0
lt=0
while fn <= len(file_name)-1:
    if c == 5:
        c=0
    print(f"""{color[c]}
*************************************************************************************

                        {lab_topic[fn]}

************************************************************************************
""")
    os.system(file_name[fn])
    c=c+1
    fn=fn+1

print("##"*50)
print("program is end................")
print("##"*50)


